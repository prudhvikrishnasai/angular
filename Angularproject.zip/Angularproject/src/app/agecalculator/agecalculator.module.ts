import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AgecalculatorRoutingModule } from './agecalculator-routing.module';
import { AgecalculatorComponent } from './agecalculator.component';
import { DatepickerModule, BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { FormsModule } from '@angular/forms';
// import { MaterialModule } from '../material/material.module';

@NgModule({
  declarations: [
    AgecalculatorComponent
  ],
  imports: [
    CommonModule,
    AgecalculatorRoutingModule,
    DatepickerModule.forRoot(),
    BsDatepickerModule.forRoot(),
    FormsModule,
    // MaterialModule
  ]
})
export class AgecalculatorModule { }
