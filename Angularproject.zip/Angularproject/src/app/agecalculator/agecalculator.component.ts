import { Component, OnInit } from '@angular/core';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
import { BsDatepickerAbstractComponent } from 'ngx-bootstrap/datepicker/base/bs-datepicker-container';

@Component({
  selector: 'app-agecalculator',
  templateUrl: './agecalculator.component.html',
  styleUrls: ['./agecalculator.component.css']
})
export class AgecalculatorComponent implements OnInit {
  datePickerConfig!: Partial<BsDatepickerConfig>;
  dateOfBirth = new Date();
  calculatedDate: any;
  calYear: any;
  calMonth: any;
  calDay: any;
  totalMonths: any;
  totalMonthDays: any;
  totalWeeks: any;
  totalWeekDays: any;
  totalDays: any;
  totalHours: any;
  totalMinutes: any;
  totalSeconds: any;
  isResultpage = false;
  currentDate = new Date();
  constructor() {}

  ngOnInit(): void {
  }
  calculateDate() {
    this.isResultpage = true;
    const year = this.currentDate.getFullYear() - this.dateOfBirth.getFullYear();
    const month = this.currentDate.getMonth() - this.dateOfBirth.getMonth();
    const day = this.currentDate.getDate() - this.dateOfBirth.getDate();
    this.calYear = year;
    this.calMonth = month;
    this.calDay = day;
    this.totalMonths = (year * 12) + month;
    this.totalMonthDays = day;
    this.totalWeeks = ((this.calMonth * 30));
    // this.totalWeeks = 
    // this.totalWeekDays = 
    // this.totalDays = 
    // this.totalHours = 
    // this.totalMinutes =
    // this.totalSeconds =
  }

}
