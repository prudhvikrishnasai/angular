import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomepageComponent } from './homepage/homepage.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';

const routes: Routes = [
    { path: 'home', component: HomepageComponent },
    { path: 'header', component: HeaderComponent },
    { path: 'footer', component: FooterComponent },
    { path: 'salarycalculator', loadChildren: () => import('./salarycalculator/salarycalculator.module')
    .then(m => m.SalarycalculatorModule) },
    { path: 'agecalculator', loadChildren: () => import('./agecalculator/agecalculator.module')
    .then(m => m.AgecalculatorModule) },
    { path: 'salaryhikecalculator', loadChildren: () => import('./salaryhikecalculator/salaryhikecalculator.module')
    .then(m => m.SalaryhikecalculatorModule) },
    { path: 'personalloancalculator', loadChildren: () => import('./personalloancalculator/personalloancalculator.module')
    .then(m => m.PersonalloancalculatorModule) },
    { path: 'homeloancalculator', loadChildren: () => import('./homeloancalculator/homeloancalculator.module')
    .then(m => m.HomeloancalculatorModule) },
    { path: 'carloancalculator', loadChildren: () => import('./carloancalculator/carloancalculator.module')
    .then(m => m.CarloancalculatorModule) },
    { path: 'registration', loadChildren: () => import('./registration/registration.module').then(m => m.RegistrationModule) },
    { path: 'dashboard', loadChildren: () => import('./dashboard/dashboard.module').then(m => m.DashboardModule) },
    { path: 'about', loadChildren: () => import('./about/about.module').then(m => m.AboutModule) },
    { path: '**', pathMatch: 'full', redirectTo: '/' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
