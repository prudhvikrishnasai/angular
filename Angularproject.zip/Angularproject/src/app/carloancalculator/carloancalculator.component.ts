import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-carloancalculator',
  templateUrl: './carloancalculator.component.html',
  styleUrls: ['./carloancalculator.component.css']
})
export class CarloancalculatorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
