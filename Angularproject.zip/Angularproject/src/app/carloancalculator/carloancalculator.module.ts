import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CarloancalculatorRoutingModule } from './carloancalculator-routing.module';
import { CarloancalculatorComponent } from './carloancalculator.component';


@NgModule({
  declarations: [
    CarloancalculatorComponent
  ],
  imports: [
    CommonModule,
    CarloancalculatorRoutingModule
  ]
})
export class CarloancalculatorModule { }
