import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CarloancalculatorComponent } from './carloancalculator.component';

describe('CarloancalculatorComponent', () => {
  let component: CarloancalculatorComponent;
  let fixture: ComponentFixture<CarloancalculatorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CarloancalculatorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CarloancalculatorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
