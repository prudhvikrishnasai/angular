import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PersonalloancalculatorRoutingModule } from './personalloancalculator-routing.module';
import { PersonalloancalculatorComponent } from './personalloancalculator.component';
import {DragDropModule} from '@angular/cdk/drag-drop';

@NgModule({
  declarations: [
    PersonalloancalculatorComponent
  ],
  imports: [
    CommonModule,
    PersonalloancalculatorRoutingModule,
    DragDropModule
  ]
})
export class PersonalloancalculatorModule { }
