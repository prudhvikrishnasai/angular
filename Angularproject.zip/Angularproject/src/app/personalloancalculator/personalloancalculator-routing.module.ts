import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PersonalloancalculatorComponent } from './personalloancalculator.component';

const routes: Routes = [{ path: '', component: PersonalloancalculatorComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PersonalloancalculatorRoutingModule { }
