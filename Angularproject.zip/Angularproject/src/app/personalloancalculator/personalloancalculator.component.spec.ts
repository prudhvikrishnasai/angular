import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PersonalloancalculatorComponent } from './personalloancalculator.component';

describe('PersonalloancalculatorComponent', () => {
  let component: PersonalloancalculatorComponent;
  let fixture: ComponentFixture<PersonalloancalculatorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PersonalloancalculatorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PersonalloancalculatorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
