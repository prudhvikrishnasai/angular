import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-personalloancalculator',
  templateUrl: './personalloancalculator.component.html',
  styleUrls: ['./personalloancalculator.component.css']
})
export class PersonalloancalculatorComponent implements OnInit {
  tableResponse: any[] = [];
  constructor() { }

  ngOnInit(): void {
    this.tableResponse = 
     [
        {
          "name": "model1",
          "modelType": "alarm_data",
          "status": "COMPLETED",
          "datasets" : "dataType1"
        },
        {
          "name": "model2",
          "modelType": "alarm_data2",
          "status": "INPROGRESS",
          "datasets" : "dataType2"
        },
        {
          "name": "model2",
          "modelType": "alarm_data2",
          "status": "INREVIEW",
          "datasets" : "dataType2"
        },
        {
          "name": "model3",
          "modelType": "alarm_data3",
          "status": "PENDING",
          "datasets" : "dataType3"
        },
        {
          "name": "model4",
          "modelType": "alarm_data4",
          "status": "DONE",
          "datasets" : "dataType4"
        }
      ];
  }
  
}
