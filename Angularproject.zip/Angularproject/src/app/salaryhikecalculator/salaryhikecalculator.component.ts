import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-salaryhikecalculator',
  templateUrl: './salaryhikecalculator.component.html',
  styleUrls: ['./salaryhikecalculator.component.css']
})
export class SalaryhikecalculatorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
