import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SalaryhikecalculatorComponent } from './salaryhikecalculator.component';

describe('SalaryhikecalculatorComponent', () => {
  let component: SalaryhikecalculatorComponent;
  let fixture: ComponentFixture<SalaryhikecalculatorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SalaryhikecalculatorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SalaryhikecalculatorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
