import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SalaryhikecalculatorComponent } from './salaryhikecalculator.component';

const routes: Routes = [{ path: '', component: SalaryhikecalculatorComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SalaryhikecalculatorRoutingModule { }
