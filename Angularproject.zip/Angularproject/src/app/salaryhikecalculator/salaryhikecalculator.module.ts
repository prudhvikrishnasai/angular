import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SalaryhikecalculatorRoutingModule } from './salaryhikecalculator-routing.module';
import { SalaryhikecalculatorComponent } from './salaryhikecalculator.component';


@NgModule({
  declarations: [
    SalaryhikecalculatorComponent
  ],
  imports: [
    CommonModule,
    SalaryhikecalculatorRoutingModule
  ]
})
export class SalaryhikecalculatorModule { }
