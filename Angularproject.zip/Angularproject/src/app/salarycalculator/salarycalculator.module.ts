import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SalarycalculatorRoutingModule } from './salarycalculator-routing.module';
import { SalarycalculatorComponent } from './salarycalculator.component';


@NgModule({
  declarations: [
    SalarycalculatorComponent
  ],
  imports: [
    CommonModule,
    SalarycalculatorRoutingModule
  ]
})
export class SalarycalculatorModule { }
