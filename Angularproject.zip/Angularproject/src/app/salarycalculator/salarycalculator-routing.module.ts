import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SalarycalculatorComponent } from './salarycalculator.component';

const routes: Routes = [{ path: '', component: SalarycalculatorComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SalarycalculatorRoutingModule { }
