import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-salarycalculator',
  templateUrl: './salarycalculator.component.html',
  styleUrls: ['./salarycalculator.component.css']
})
export class SalarycalculatorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
