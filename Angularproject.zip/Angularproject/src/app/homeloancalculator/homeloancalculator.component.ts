import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homeloancalculator',
  templateUrl: './homeloancalculator.component.html',
  styleUrls: ['./homeloancalculator.component.css']
})
export class HomeloancalculatorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
