import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HomeloancalculatorComponent } from './homeloancalculator.component';

describe('HomeloancalculatorComponent', () => {
  let component: HomeloancalculatorComponent;
  let fixture: ComponentFixture<HomeloancalculatorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HomeloancalculatorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HomeloancalculatorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
