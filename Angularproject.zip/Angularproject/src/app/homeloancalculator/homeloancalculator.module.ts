import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HomeloancalculatorRoutingModule } from './homeloancalculator-routing.module';
import { HomeloancalculatorComponent } from './homeloancalculator.component';


@NgModule({
  declarations: [
    HomeloancalculatorComponent
  ],
  imports: [
    CommonModule,
    HomeloancalculatorRoutingModule
  ]
})
export class HomeloancalculatorModule { }
