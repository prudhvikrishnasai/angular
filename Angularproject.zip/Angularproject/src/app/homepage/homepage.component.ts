import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FEATURES } from 'src/config/app.config';

@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit {
  featureToggleData = FEATURES;
  constructor() { }

  ngOnInit(): void {
  }

}
