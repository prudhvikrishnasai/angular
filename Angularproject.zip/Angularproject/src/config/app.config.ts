export const FEATURES_VALUES = {
    AgeCalculator: true,
    PersonalLoanCalculator: true,
    HomeLoanCalculator: true,
    SalaryCalculator: true,
    CarLoanCalculator: true,
    SalaryHikeCalculator: true
};
export const FEATURES = {
    AgeCalculator: FEATURES_VALUES.AgeCalculator,
    PersonalLoanCalculator: FEATURES_VALUES.PersonalLoanCalculator,
    HomeLoanCalculator: FEATURES_VALUES.HomeLoanCalculator,
    SalaryCalculator: FEATURES_VALUES.SalaryCalculator,
    CarLoanCalculator: FEATURES_VALUES.CarLoanCalculator,
    SalaryHikeCalculator: FEATURES_VALUES.SalaryHikeCalculator,
    nAgeCalculator: !FEATURES_VALUES.AgeCalculator,
    nPersonalLoanCalculator: !FEATURES_VALUES.PersonalLoanCalculator,
    nHomeLoanCalculator: !FEATURES_VALUES.HomeLoanCalculator,
    nSalaryCalculator: !FEATURES_VALUES.SalaryCalculator,
    nCarLoanCalculator: !FEATURES_VALUES.CarLoanCalculator,
    nSalaryHikeCalculator: !FEATURES_VALUES.SalaryHikeCalculator
};
export const SOCKET_FEATURE = {
    AgeCalculator: '',
    PersonalLoanCalculator: 'PersonalLoanCalculator',
    HomeLoanCalculator: 'HomeLoanCalculatordetection',
    SalaryCalculator: '',
    CarLoanCalculator: 'CarLoanCalculator',
    SalaryHikeCalculator: 'PersonalLoanCalculator'
};
export const FEATURES_DETAILS = {
    AgeCalculator: {
        Active: true,
        link: '/AgeCalculator',
        linkActive: 'active',
        lable: 'AgeCalculator',
        feature: 'AgeCalculator'
        },
    PersonalLoanCalculator: {
        Active: true,
        link: '/PersonalLoanCalculator',
        linkActive: 'active',
        lable: 'PersonalLoanCalculator',
        feature: 'PersonalLoanCalculator'
        },
    HomeLoanCalculator: {
        Active: true,
        link: '/HomeLoanCalculator',
        linkActive: 'active',
        lable: 'HomeLoanCalculator',
        feature: 'HomeLoanCalculator'
        },
    SalaryCalculator: {
        Active: true,
        link: '/SalaryCalculator',
        linkActive: 'active',
        lable: 'SalaryCalculator',
        feature: 'SalaryCalculator'
        },
    CarLoanCalculator: {
        Active: true,
        link: '/CarLoanCalculator',
        linkActive: 'active',
        lable: 'CarLoanCalculator',
        feature: 'CarLoanCalculator'
        },
    SalaryHikeCalculator: {
        Active: true,
        link: '/SalaryHikeCalculator',
        linkActive: 'active',
        lable: 'SalaryHikeCalculator',
        feature: 'SalaryHikeCalculator'
        }
};
